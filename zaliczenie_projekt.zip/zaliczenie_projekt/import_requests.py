import requests
import time
import csv

# === KONFIGURACJA ===
BEARER_TOKEN = "AAAAAAAAAAAAAAAAAAAAAB2q1wEAAAAAAeAbxok8gND%2FCgws43f9Gr8%2B6tA%3DlCHG1RiS5WbdCY5dp0aeYOMx2suop4L9kPwZUxfvjGh04byQqW"
elon_id = "44196397"  # ID Elona Muska na Twitterze
keywords = ["btc", "bitcoin", "ethereum", "eth", "crypto", "cryptocurrency", "doge"]

# Budowanie zapytania
query = f"({' OR '.join(keywords)}) from:{elon_id} -is:retweet -is:reply lang:en"

# API endpoint (pełne archiwum)
search_url = "https://api.twitter.com/2/tweets/search/all"

# Nagłówki
headers = {
    "Authorization": f"Bearer {BEARER_TOKEN}",
}

# Parametry zapytania
params = {
    "query": query,
    "max_results": 100,  # maksymalna wartość
    "tweet.fields": "created_at,text",
    "start_time": "2010-01-01T00:00:00Z",  # początek zakresu
    "end_time": "2025-01-01T00:00:00Z",    # koniec zakresu
}

# Pobieranie danych z Twittera
def search_all_tweets():
    all_tweets = []
    next_token = None

    while True:
        if next_token:
            params["next_token"] = next_token

        response = requests.get(search_url, headers=headers, params=params)
        if response.status_code != 200:
            print("Błąd:", response.status_code, response.text)
            break

        json_data = response.json()
        tweets = json_data.get("data", [])
        all_tweets.extend(tweets)

        print(f"Pobrano: {len(tweets)} tweetów (łącznie: {len(all_tweets)})")

        next_token = json_data.get("meta", {}).get("next_token")
        if not next_token:
            break

        time.sleep(1)  # limit API: 1 zapytanie/sekunda

    return all_tweets

# Zapis do pliku CSV
def save_to_csv(tweets, filename="elon_crypto_tweets.csv"):
    with open(filename, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["created_at", "text"])
        for t in tweets:
            writer.writerow([t["created_at"], t["text"].replace('\n', ' ')])

# Główna funkcja
if __name__ == "__main__":
    tweets = search_all_tweets()
    print(f"\nZnaleziono {len(tweets)} tweetów spełniających kryteria.")
    save_to_csv(tweets)
    print("Zapisano do elon_crypto_tweets.csv")
