data<-read.csv("BTCprice1.csv", sep=";", dec=",")
#data<- read.csv("C:\\Users\\Jakub\\Desktop\\czwarty_sem\\ekonometria_lab\\zaliczenie_projekt\\BTCprice.csv", header=TRUE, sep=";", stringsAsFactors = FALSE, dec=",")
head(data)

model<-lm(Price ~ VolumeM + USAvgKWHPrice + BTCCirculation + InflationRateUS + GoogleTrends + HasMuskMentioned + Difficulty , data)

summary(model)

