import requests
from bs4 import BeautifulSoup
import re
import pandas as pd
from datetime import datetime
from decimal import Decimal

def extract_hashrate_data(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Znajdź skrypt zawierający dane
    scripts = soup.find_all('script')
    data_script = None
    
    for script in scripts:
        if 'd = new Dygraph' in script.text:
            data_script = script.text
            break
    
    if not data_script:
        raise ValueError("Nie znaleziono danych w skrypcie")
    
    # Wyodrębnij część z danymi
    raw_data = data_script.split('[[[')[-1].split(']]]')[0] + ']]'
    
    # Poprawione wyrażenie regularne (uwzględnia wartości dziesiętne i jednostki)
    pattern = re.compile(r'new Date\("([^"]+)"\),([\d.]+)([A-Za-z]*)')  # Dodano grupę dla jednostek
    matches = pattern.findall(raw_data)
    
    dates = []
    values = []
    
    # Słownik mnożników dla jednostek
    unit_multipliers = {
        'K': 1e3,
        'M': 1e6,
        'G': 1e9,
        'T': 1e12,
        'P': 1e15,
        'E': 1e18,
        '': 1  # brak jednostki
    }
    
    for match in matches:
        date_str, value_str, unit = match
        dates.append(datetime.strptime(date_str, '%Y/%m/%d').strftime('%Y-%m-%d'))
        
        # Konwersja wartości z uwzględnieniem jednostki
        try:
            value = float(value_str) * unit_multipliers.get(unit.upper(), 1)
            values.append(int(value))  # Możesz użyć int() lub zostawić float()
        except ValueError:
            values.append(None)  # W przypadku błędu konwersji
    
    # Tworzenie DataFrame
    df = pd.DataFrame({
        'Date': dates,
        'Hashrate': values
    })
    
    return df

# Użycie funkcji
url = 'https://bitinfocharts.com/comparison/bitcoin-hashrate.html#alltime'
data = extract_hashrate_data(url)

# Zapis do CSV
data.to_csv('hashrate_daily.csv', index=False)
print("Dane zostały zapisane do hashrate_daily.csv")

# Wyświetlenie przykładowych danych
print("\nPrzykładowe dane:")
print(data.head())