import pandas as pd
from datetime import datetime

def aggregate_monthly_trends(input_file, output_file):
    """
    Agreguje dane Google Trends do sumy miesięcznej, przeliczając wartości na pełne liczby
    
    :param input_file: ścieżka do pliku CSV z danymi dziennymi
    :param output_file: ścieżka do zapisu danych miesięcznych
    """
    try:
        # Wczytanie danych
        df = pd.read_csv(input_file, parse_dates=['Date'])
        print(f"Wczytano dane z {input_file}")
        
        # Sprawdzenie czy wartości są numeryczne
        df['Google_Trends_Value'] = pd.to_numeric(df['Google_Trends_Value'], errors='coerce')
        df = df.dropna(subset=['Google_Trends_Value'])
        
        # Przeliczenie wartości z ułamków milionów na pełne liczby
        df['Absolute_Value'] = (df['Google_Trends_Value'] * 1_000_000).round().astype('int64')
        
        # Agregacja miesięczna
        df['YearMonth'] = df['Date'].dt.strftime('%Y-%m')
        monthly = df.groupby('YearMonth', as_index=False)['Absolute_Value'].sum()
        
        # Zapis wyników
        monthly.to_csv(output_file, index=False)
        print(f"\nDane miesięczne zapisano do {output_file}")
        print("\nPrzykładowe dane:")
        print(monthly.head())
        
    except Exception as e:
        print(f"Wystąpił błąd: {e}")

# Przykład użycia
if __name__ == "__main__":
    input_csv = 'bitcoin_google_trends.csv'  # Twój plik wejściowy
    output_csv = 'bitcoin_monthly_trends_absolute.csv'  # Plik wynikowy
    
    aggregate_monthly_trends(input_csv, output_csv)