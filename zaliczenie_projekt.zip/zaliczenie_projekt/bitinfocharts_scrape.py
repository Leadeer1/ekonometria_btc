import requests
from bs4 import BeautifulSoup
import re
import pandas as pd
from datetime import datetime
from decimal import Decimal

def extract_google_trends_data(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Znajdź skrypt zawierający dane
    scripts = soup.find_all('script')
    data_script = None
    
    for script in scripts:
        if 'd = new Dygraph' in script.text:
            data_script = script.text
            break
    
    if not data_script:
        raise ValueError("Nie znaleziono danych w skrypcie")
    
    # Wyodrębnij część z danymi
    raw_data = data_script.split('[[[')[-1].split(']]]')[0] + ']]'
    
    # Poprawione wyrażenie regularne (uwzględnia wartości dziesiętne)
    pattern = re.compile(r'new Date\("([^"]+)"\),([\d.]+)')  # Dodano \. do wykrywania kropek
    matches = pattern.findall(raw_data)
    
    dates = []
    values = []
    
    for match in matches:
        dates.append(datetime.strptime(match[0], '%Y/%m/%d').strftime('%Y-%m-%d'))
        # Konwertujemy wartość na float (zamiast int)
        value_str = match[1]
        value_int = int(Decimal(value_str))
        values.append(value_int)
    
    # Tworzenie DataFrame
    df = pd.DataFrame({
        'Date': dates,
        'Google_Trends_Value': values
    })
    
    return df

# Użycie funkcji
url = 'https://bitinfocharts.com/comparison/bitcoin-hashrate.html#alltime'
data = extract_google_trends_data(url)

# Zapis do CSV
data.to_csv('hashrate_daily.csv', index=False,)
print("Dane zostały zapisane do hashrate_daily.csv")

# Wyświetlenie przykładowych danych
print("\nPrzykładowe dane:")
print(data.head())