import pandas as pd
from datetime import datetime

def aggregate_monthly_trends(input_file, output_file, decimal_places=6):
    """
    Agreguje dane Google Trends do sumy miesięcznej z poprawnym zaokrągleniem
    
    :param input_file: ścieżka do pliku CSV z danymi dziennymi
    :param output_file: ścieżka do zapisu danych miesięcznych
    :param decimal_places: liczba miejsc po przecinku do zaokrąglenia
    """
    try:
        # Wczytanie danych z dokładnym parsowaniem dat
        df = pd.read_csv(input_file, parse_dates=['Date'])
        
        # Sprawdzenie czy wartości są numeryczne
        df['Google_Trends_Value'] = pd.to_numeric(df['Google_Trends_Value'], errors='coerce')
        df = df.dropna(subset=['Google_Trends_Value'])
        
        # Agregacja miesięczna z zaokrągleniem
        df['YearMonth'] = df['Date'].dt.strftime('%Y-%m')
        monthly = df.groupby('YearMonth', as_index=False)['Google_Trends_Value'] \
                   .sum() \
                   .round(decimal_places)
        
        # Poprawne formatowanie (usuwanie niepotrzebnych zer)
        monthly['Google_Trends_Value'] = monthly['Google_Trends_Value'].apply(
            lambda x: f"{x:.6f}".rstrip('0').rstrip('.') if '.' in f"{x:.6f}" else f"{x:.6f}"
        )
        
        monthly.to_csv(output_file, index=False)
        print(f"Dane zapisano do {output_file}")
        print("\nPrzykładowe wyniki:")
        print(monthly.head())
        
    except Exception as e:
        print(f"Błąd: {e}")

# Użycie:
aggregate_monthly_trends(
    input_file='bitcoin_google_trends.csv',
    output_file='bitcoin_monthly_trends_corrected.csv',
    decimal_places=6
)